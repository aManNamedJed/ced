<?php
$atts = array();
parse_str( $data, $atts );
$el_class  = '';

extract( shortcode_atts( array(
   'meta_color' => ''
), $atts ) );

 
$postID = $post->ID;
if ( !empty ($meta_color) ) {
	$el_class = ' style="color:'.$el_class.'"';
}
$allcats = '<p>';
$categories = wp_get_post_terms( $postID, 'portfolio-category');
	foreach($categories as $category){
		$allcats .= '<span class="portfolio-cat"'.$el_class.'>'.esc_attr($category->name).'</span>'; 
	}
$allcats .= '</p>';
return $allcats;